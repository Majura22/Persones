<?php
$sv = "localhost";
$user = "root";
$password = "";
$db = "BD_persones";

$conn = new mysqli($sv, $user, $password, $db);

if ($conn->connect_error) {
    die("Connexió fallida: " . $conn->connect_error);
}

$sql = "SELECT dni, nom, cognoms FROM Persones";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>DNI</th><th>Nom</th><th>Cognoms</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["dni"]. "</td><td>" . $row["nom"]. "</td><td>" . $row["cognoms"]. "</td></tr>";
    }
    echo "</table>";

	echo "<br>";
	echo "<br>";
	echo "<br>";
	
    echo "<form action='modificarPersona.php' method='post'>
            <input type='submit' value='MODIFICAR PERSONAS'>
          </form>";
		  
    echo "<form action='buscarPersona.php' method='post'>
            <input type='submit' value='BUSCAR PERSONA'>
          </form>";
    
    echo "<form action='nuevaPersona.php' method='post'>
            <input type='submit' value='AÑADIR PERSONA'>
          </form>";

} else {
    echo "No hi ha dades.";
}

$conn->close();
?>
