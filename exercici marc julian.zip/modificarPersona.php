<?php
$sv = "localhost";
$user = "root";
$password = "";
$db = "BD_persones";

$conn = new mysqli($sv, $user, $password, $db);

if ($conn->connect_error) {
    die("Connexió fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    foreach ($_POST['dni'] as $key => $dni) {
        $nom = $_POST['nom'][$key];
        $cognoms = $_POST['cognoms'][$key];
        $data_naixement = $_POST['data_naixement'][$key];
        $email = $_POST['email'][$key];
        $telefon = $_POST['telefon'][$key];
        $comentaris = $_POST['comentaris'][$key];

        $sql_actualizar = "UPDATE Persones SET nom='$nom', cognoms='$cognoms', data_naixement='$data_naixement', email='$email', telefon='$telefon', comentaris='$comentaris' WHERE dni='$dni'";

        if ($conn->query($sql_actualizar) !== TRUE) {
            echo "Error al actualizar las datos: " . $conn->error;
        }
    }

    echo "Todas las personas se han actualizado correctamente.";
}

$sql_obtener_datos = "SELECT * FROM Persones";
$result_obtener_datos = $conn->query($sql_obtener_datos);

if ($result_obtener_datos->num_rows > 0) {
    echo "<h2>Actualizar Todas las Personas</h2>";
    echo "<form action='' method='post'>";

    while ($row = $result_obtener_datos->fetch_assoc()) {
        echo "<input type='hidden' name='dni[]' value='" . $row["dni"] . "'>";
        echo "Nom: <input type='text' name='nom[]' value='" . $row["nom"] . "'><br>";
        echo "Cognoms: <input type='text' name='cognoms[]' value='" . $row["cognoms"] . "'><br>";
        echo "Data Naixement: <input type='date' name='data_naixement[]' value='" . $row["data_naixement"] . "'><br>";
        echo "Email: <input type='email' name='email[]' value='" . $row["email"] . "'><br>";
        echo "Telèfon: <input type='text' name='telefon[]' value='" . $row["telefon"] . "'><br>";
        echo "Comentaris: <textarea name='comentaris[]'>" . $row["comentaris"] . "</textarea><br>";
        echo "<hr>";
    }

    echo "<input type='submit' value='Guardar Actualizaciones'>";
    echo "</form>";
} else {
    echo "No hay personas en la base de datos.";
}
	echo "<br>";
	echo "<br>";
	echo "<br>";
	
    echo "<form action='index.php' method='post'>
            <input type='submit' value='VOLVER'>
          </form>";
	$conn->close();
?>
