CREATE DATABASE IF NOT EXISTS BD_Persones;
USE BD_Persones;

CREATE TABLE Persones (
    dni Varchar(15) PRIMARY KEY,
    nom Varchar(50) NOT NULL,
    cognoms Varchar(50) NOT NULL,
    data_naixement DATE NOT NULL,
    email Varchar(50) UNIQUE NOT NULL,
    telefon Varchar(15),
    comentaris Varchar(150)
);

INSERT INTO Persones (dni, nom, cognoms, data_naixement, email, telefon, comentaris)
VALUES 
    ('12345678A', 'Marc', 'Julian', '2002-06-08', 'maarc.juliaan@hotmail.com', '608002528', 'Comentario M'),
    ('98765432B', 'Paola', 'Santty', '1999-09-21', 'paolaa.santtyy@hotmail.com', '666999666', 'Comentario P');