<?php
$sv = "localhost";
$user = "root";
$password = "";
$db = "BD_persones";

$conn = new mysqli($sv, $user, $password, $db);

if ($conn->connect_error) {
    die("Connexió fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['buscar_dni'])) {
    $dni_a_buscar = $_POST["dni_a_buscar"];

    $sql_buscar = "SELECT * FROM Persones WHERE dni = '$dni_a_buscar'";
    $result_buscar = $conn->query($sql_buscar);

    if ($result_buscar->num_rows > 0) {
        echo "<h2>Resultats de la cerca:</h2>";
        echo "<table><tr><th>DNI</th><th>Nom</th><th>Cognoms</th><th>Data Naixement</th><th>Email</th><th>Telèfon</th><th>Comentaris</th></tr>";
        while ($row = $result_buscar->fetch_assoc()) {
            echo "<tr><td>" . $row["dni"] . "</td><td>" . $row["nom"] . "</td><td>" . $row["cognoms"] . "</td><td>" . $row["data_naixement"] . "</td><td>" . $row["email"] . "</td><td>" . $row["telefon"] . "</td><td>" . $row["comentaris"] . "</td></tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No s'ha trobat cap persona amb aquest DNI.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar i Afegir Persona</title>
</head>
<body>
    <h2>Cerca i Afegir Persona</h2>
    
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        DNI a buscar: <input type="text" name="dni_a_buscar" placeholder="Introdueix el DNI">
        <input type="submit" name="buscar_dni" value="Cercar">
    </form>

</body>
</html>

<?php
	echo "<br>";
	echo "<br>";
	echo "<br>";
	
    echo "<form action='index.php' method='post'>
            <input type='submit' value='VOLVER'>
          </form>";
$conn->close();
?>
