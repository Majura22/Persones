<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Afegir Persona Manualment</title>
</head>
<body>
    <h2>Afegir Persona Manualment</h2>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        Nom: <input type="text" name="nom" placeholder="Introdueix el nom" required><br>
        Cognoms: <input type="text" name="cognoms" placeholder="Introdueix els cognoms" required><br>
        DNI: <input type="text" name="dni" placeholder="Introdueix el DNI" required><br>
        Data Naixement: <input type="date" name="data_naixement" required><br>
        Email: <input type="email" name="email" placeholder="Introdueix l'email" required><br>
        Telèfon: <input type="text" name="telefon" placeholder="Introdueix el telèfon"><br>
        Comentaris: <textarea name="comentaris" placeholder="Introdueix comentaris"></textarea><br>
        <input type="submit" value="Afegir Persona">
    </form>
</body>
</html>
<?php
$sv = "localhost";
$user = "root";
$password = "";
$db = "BD_persones";

$conn = new mysqli($sv, $user, $password, $db);

if ($conn->connect_error) {
    die("Connexió fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = isset($_POST["nom"]) ? $_POST["nom"] : "";
    $cognoms = isset($_POST["cognoms"]) ? $_POST["cognoms"] : "";
    $dni = isset($_POST["dni"]) ? $_POST["dni"] : "";
    $data_naixement = isset($_POST["data_naixement"]) ? $_POST["data_naixement"] : "";
    $email = isset($_POST["email"]) ? $_POST["email"] : "";
    $telefon = isset($_POST["telefon"]) ? $_POST["telefon"] : "";
    $comentaris = isset($_POST["comentaris"]) ? $_POST["comentaris"] : "";

    $sql = "INSERT INTO Persones (dni, nom, cognoms, data_naixement, email, telefon, comentaris) 
            VALUES ('$dni', '$nom', '$cognoms', '$data_naixement', '$email', '$telefon', '$comentaris')";

}

	echo "<br>";
	echo "<br>";
	echo "<br>";
	
    echo "<form action='index.php' method='post'>
            <input type='submit' value='VOLVER'>
          </form>";

    if ($_SERVER["REQUEST_METHOD"] == "POST" && $conn->query($sql) === TRUE) {
        echo "<p>Persona afegida amb èxit.</p>";
    } else {
	}
	$conn->close();
?>
